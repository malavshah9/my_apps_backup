import { Routes, RouterModule } from "@angular/router";

import { AddEventComponent } from "./add-event/add-event.component";
import { EventComponent } from "./event.component";

const arr: Routes = [
  { path: '', redirectTo: '/eventDisplay', pathMatch: 'full' },
  { path: 'eventDisplay', component: EventComponent },
  { path: 'addEvent', component: AddEventComponent }
];

export const EventRouting = RouterModule.forChild(arr);
