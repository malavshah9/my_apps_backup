import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EventRouting } from './event.routing';

import { AddEventComponent } from './add-event/add-event.component';
import { EventComponent } from './event.component';

@NgModule({
  declarations: [EventComponent, AddEventComponent],
  imports: [CommonModule, EventRouting],
  providers: []
})

export class EventModule { }
