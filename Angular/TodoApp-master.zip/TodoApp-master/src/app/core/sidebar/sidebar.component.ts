import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';


@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {

  @Input() x: string = '';
  @Output() zeel = new EventEmitter<string>();
  constructor() { }

  ngOnInit() {
  }

  onSearch(searchTerm: string) {
    this.zeel.emit(searchTerm);
  }
}
