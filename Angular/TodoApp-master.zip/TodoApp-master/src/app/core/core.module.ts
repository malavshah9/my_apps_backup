import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { MatButtonModule, MatInputModule, MatFormFieldModule, MatIconModule } from '@angular/material';

import { TodoPageComponent } from '../todo-page/todo-page.component';
import { FooterComponent } from './footer/footer.component';

@NgModule({
  declarations: [TodoPageComponent,
    FooterComponent],
  imports: [CommonModule,
    FormsModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatIconModule],
  exports: [TodoPageComponent,
    FooterComponent,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatIconModule]
})

export class CoreModule { }
