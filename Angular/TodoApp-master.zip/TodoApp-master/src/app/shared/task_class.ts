// tslint:disable-next-line:class-name
export class Task_Class {
    constructor(public Id: number, public Title: string, public Status: string) {

    }
}
