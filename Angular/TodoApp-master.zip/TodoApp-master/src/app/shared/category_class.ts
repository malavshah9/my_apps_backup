export class Category_Class {
    constructor(public cat_id: number,
        public cat_name: string) {

    }
}