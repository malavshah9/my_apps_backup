import { Component, OnInit } from '@angular/core';
import { Task_Class } from '../shared/task_class';

@Component({
  selector: 'app-todo-page',
  templateUrl: './todo-page.component.html',
  styleUrls: ['./todo-page.component.css']
})
export class TodoPageComponent implements OnInit {

  value = 'Clear me';

  arrTask: Task_Class[] = [
    new Task_Class(1, 'HTML', 'done'),
    new Task_Class(2, 'C++', 'done'),
    new Task_Class(3, 'Ionic', 'done'),
    new Task_Class(4, 'Angular', 'pending'),
    new Task_Class(5, 'node', 'pending')
  ];

  i: number = this.arrTask.length;
  title: string = '';

  constructor() { }

  ngOnInit() {
  }

  addTask() {
    this.arrTask.push(new Task_Class(this.i + 1, this.title, 'pending'));
    this.i++;
    this.title = '';
  }

  removeTask(item) {
    this.arrTask.splice(this.arrTask.indexOf(item), 1);
  }

  onEdit(item: Task_Class) {
    if (item.Status == 'done') {
      item.Status = 'pending';
    } else {
      item.Status = 'done';
    }
  }
}
