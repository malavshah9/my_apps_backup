import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Community_User_Category_Class } from '../shared/community_user_cat';

@Injectable({
  providedIn: 'root'
})
export class CommunityDataService {

  url: string = 'http://letsmeetbackend.herokuapp.com/community/';

  constructor(private _http: HttpClient) { }

  getAllCommunities() {
    return this._http.get(this.url);
  }

  addCommunity(fd: FormData) {
    return this._http.post(this.url, fd);
  }
}
