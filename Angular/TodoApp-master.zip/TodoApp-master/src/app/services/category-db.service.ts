import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CategoryDbService {

  url: string = 'https://letsmeetbackend.herokuapp.com/category/';

  constructor(public http: HttpClient) { }

  getAllCategories() {
    return this.http.get(this.url);
  }
}
