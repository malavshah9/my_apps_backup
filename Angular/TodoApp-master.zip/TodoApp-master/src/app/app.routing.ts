import { Routes, RouterModule, PreloadAllModules } from '@angular/router';

import { TodoPageComponent } from './todo-page/todo-page.component';
import { NotFoundComponent } from './not-found/not-found.component';

const arr: Routes = [
  { path: '', redirectTo: '/todo', pathMatch: 'full' },
  { path: 'community', loadChildren: 'src/app/community/community.module#CommunityModule' },
  { path: 'event', loadChildren: 'src/app/event/event.module#EventModule' },
  { path: 'todo', component: TodoPageComponent },
  { path: 'notFound', component: NotFoundComponent },
  { path: '**', redirectTo: '/notFound', pathMatch: 'full' }
];
export const routing = RouterModule.forRoot(arr, { preloadingStrategy: PreloadAllModules });
