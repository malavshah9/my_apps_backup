import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommunityDataService } from '../services/community-data.service';
import { Community_User_Category_Class } from '../shared/community_user_cat';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';

@Component({
  selector: 'app-community',
  templateUrl: './community.component.html',
  styleUrls: ['./community.component.css']
})
export class CommunityComponent implements OnInit, AfterViewInit {

  @ViewChild('paginator') paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  arr: Community_User_Category_Class[] = [];
  arr1 = new MatTableDataSource<Community_User_Category_Class>();
  str: string = "Zeel";

  displayedColumns = ['comm_name', 'user_name'];

  constructor(private _router: Router,
    private _dataCommunity: CommunityDataService) { }

  ngOnInit() {
    this._dataCommunity.getAllCommunities().subscribe(
      (data: Community_User_Category_Class[]) => {
        this.arr = data;
        this.arr1.data = data;
      },
      function (err) {
        alert(err);
      },
      function () {
        console.log('finally');
      }
    );
  }

  ngAfterViewInit() {
    this.arr1.paginator = this.paginator;
    this.arr1.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.arr1.filter = filterValue;
  }

  onCLick() {
    this._router.navigate(['/todo']);
  }

  search(value: string) {
    console.log(value);
    this.arr = this.arr.filter((x) => x.comm_name.startsWith(value));
  }

}
