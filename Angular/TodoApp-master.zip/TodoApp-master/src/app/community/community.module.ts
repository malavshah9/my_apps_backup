import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { SidebarComponent } from '../core/sidebar/sidebar.component';
import { CommunityComponent } from './community.component';
import { AddCommunityComponent } from 'src/app/community/add-community/add-community.component';

import { communityRouting } from './community.routing';
import { MatTableModule, MatFormFieldModule, MatInputModule, MatPaginatorModule, MatSortModule, MatProgressSpinnerModule, MatCardModule } from '@angular/material';

@NgModule({
  declarations: [SidebarComponent,
    CommunityComponent,
    AddCommunityComponent],
  imports: [CommonModule,
    ReactiveFormsModule,
    communityRouting,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatPaginatorModule,
    MatSortModule,
    MatProgressSpinnerModule,
    MatCardModule
  ],
  exports: [MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatPaginatorModule,
    MatSortModule,
    MatProgressSpinnerModule,
    MatCardModule
  ],
  providers: []
})

export class CommunityModule { }
