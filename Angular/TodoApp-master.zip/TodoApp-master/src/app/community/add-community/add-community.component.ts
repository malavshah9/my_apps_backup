import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';

import { CategoryDbService } from '../../services/category-db.service';
import { Category_Class } from '../../shared/category_class';
import { Community_User_Category_Class } from '../../shared/community_user_cat';
import { CommunityDataService } from '../../services/community-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-community',
  templateUrl: './add-community.component.html',
  styleUrls: ['./add-community.component.css']
})
export class AddCommunityComponent implements OnInit {

  communityForm: FormGroup;


  arrCat: Category_Class[] = [];

  selectedFile: File = null;

  constructor(private router: Router,
    public _dataCategory: CategoryDbService,
    private _dataCommu: CommunityDataService) { }

  ngOnInit() {

    this.communityForm = new FormGroup({
      'comm_name': new FormControl(null, [Validators.required, this.myValidation.bind(this)]),
      'comm_des': new FormControl(null, Validators.required),
      'comm_pic': new FormControl(null, Validators.required),
      'category_id': new FormControl(null)
    });

    this._dataCategory.getAllCategories().subscribe(
      (data: Category_Class[]) => {
        this.arrCat = data;
        console.log(data);
      },
      function (err) {
        alert(err);
      },
      function () {

      }
    );
  }

  onFileSelected(value) {
    this.selectedFile = <File>value.target.files[0];
    console.log(value);
  }

  arr: string[] = ['xyz', 'abc', 'mno'];
  myValidation(control: AbstractControl): { [s: string]: boolean } {
    if (this.arr.indexOf(control.value) !== -1) {
      return { 'Communitynameisnotproper': true };
    }
    return null;
  }
  onSubmit() {
    console.log(this.communityForm);
    const fd = new FormData();
    fd.append('comm_id', null);
    fd.append('comm_name', this.communityForm.value.comm_name);
    fd.append('comm_des', this.communityForm.value.comm_des);
    fd.append('image', this.selectedFile, this.selectedFile.name);
    fd.append('comm_date', null);
    fd.append('comm_rating', null);
    fd.append('created_by', 'zeel91297@gmail.com');
    fd.append('comm_fk_cat_id', this.communityForm.value.category_id);

    this._dataCommu.addCommunity(fd).subscribe(
      (data: any) => {
        alert('Done');
        this.router.navigate(['/community']);
      },
      function (err) {
        alert(err);
      },
      function () {
      }
    );
  }
}
  /* onAddCommunity(commuForm) {

    this.comm_name = commuForm.value.comm_name;
    this.comm_des = commuForm.value.comm_des;
    this.comm_fk_cat_id = commuForm.value.category_id;

    const fd = new FormData();
    alert(this.created_by);
    fd.append('comm_id', this.comm_id);
    fd.append('comm_name', this.comm_name);
    fd.append('comm_des', this.comm_des);
    fd.append('image', this.selectedFile, this.selectedFile.name);
    fd.append('comm_date', this.comm_date);
    fd.append('comm_rating', this.comm_rating);
    fd.append('created_by', this.created_by);
    fd.append('comm_fk_cat_id', this.comm_fk_cat_id);

    this._dataCommu.addCommunity(fd).subscribe(
      (data: any) => {
        alert('Done');
        this.router.navigate(['/communities']);
      },
      function (err) {
        alert(err);
      },
      function () {
      }
    );
  } */

