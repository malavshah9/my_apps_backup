import { Routes, RouterModule } from '@angular/router';
import { CommunityComponent } from './community.component';
import { AddCommunityComponent } from './add-community/add-community.component';

const arr: Routes = [
    { path: '', redirectTo: '/communityDisplay', pathMatch: 'full' },
    { path: 'communityDisplay', component: CommunityComponent },
    { path: 'addCommunity', component: AddCommunityComponent }
];

export const communityRouting = RouterModule.forChild(arr);